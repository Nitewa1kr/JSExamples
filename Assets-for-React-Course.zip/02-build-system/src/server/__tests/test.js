describe("Something", () => {
	it("works", () => expect(true).toBe(true));
	it("doesn't work", () => expect(true).toBe(true));
});