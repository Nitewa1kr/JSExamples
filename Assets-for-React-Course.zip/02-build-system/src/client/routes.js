import React from "react";

import AppContainer from "./components/app";

export default function() {
	return <AppContainer />;
}