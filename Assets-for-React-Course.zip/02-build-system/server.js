require("source-map-support").install();
require("./build/server");